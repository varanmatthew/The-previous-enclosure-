<?php 
	include 'config.php';
	
	if(isset($_POST['contact_submit'])){
		$name = $_POST['name'];
		$phone = $_POST['phone'];
		$department = $_POST['dept'];
		$email = $_POST['email'];
		$subject = $_POST['subject'];
		$topic = $_POST['topic'];
		$message = $_POST['message'];
		
		$sql = "INSERT INTO `contact`(`id`, `name`, `email`, `phone`, `subject`, `message`, `department`, `topic`, `created_date`) VALUES ( NULL , '$name' , '$email' , '$phone' , '$subject' , '$message' , '$department' , '$topic' , NOW())";
		
		$result = mysqli_query($conn , $sql);
		
		if($result){
			header("Location: ../index.html");
		} else {
			echo "failed";
		}
	}
?>