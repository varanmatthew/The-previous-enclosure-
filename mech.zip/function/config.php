<?php 
	define("SERVER","localhost");
	define("USER","root");
	define("PASS","");
	define("DB","mech");
	
	$conn = mysqli_connect(SERVER , USER , PASS , DB) or die("invalid database");

?>